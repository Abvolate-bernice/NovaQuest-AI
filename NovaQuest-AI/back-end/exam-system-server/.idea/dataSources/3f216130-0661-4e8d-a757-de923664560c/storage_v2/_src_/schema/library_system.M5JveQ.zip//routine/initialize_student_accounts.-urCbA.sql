create
    definer = root@localhost procedure initialize_student_accounts(IN semester_name varchar(20))
BEGIN
    -- 重置学生借阅计数和账户状态（不包括已冻结的）
    UPDATE students
    SET current_borrow_count = 0,
        account_status = '正常',
        updated_at = CURRENT_TIMESTAMP
    WHERE account_status != '冻结';

    -- 记录初始化日志
    INSERT INTO system_logs (
        operation_type,
        operation_desc,
        operator_id,
        operation_time
    ) VALUES (
        '账户初始化',
        CONCAT('学期初学生账户初始化完成，学期：', semester_name),
        'SYSTEM', -- 假设系统操作者ID为'SYSTEM'
        CURRENT_TIMESTAMP
    );
END;

