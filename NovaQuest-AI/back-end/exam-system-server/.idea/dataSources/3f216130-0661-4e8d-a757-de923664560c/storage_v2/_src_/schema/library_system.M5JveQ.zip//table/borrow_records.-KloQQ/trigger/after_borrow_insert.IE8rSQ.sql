create definer = root@localhost trigger after_borrow_insert
    after insert
    on borrow_records
    for each row
BEGIN
    UPDATE books
    SET available_copies = available_copies - 1,
        updated_at = CURRENT_TIMESTAMP
    WHERE isbn = NEW.isbn;

    UPDATE students
    SET current_borrow_count = current_borrow_count + 1,
        updated_at = CURRENT_TIMESTAMP
    WHERE student_id = NEW.student_id;
END;

