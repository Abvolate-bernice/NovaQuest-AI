create definer = root@localhost view student_borrow_history as
select `s`.`student_id`      AS `student_id`,
       `s`.`name`            AS `student_name`,
       `s`.`department`      AS `department`,
       `b`.`isbn`            AS `isbn`,
       `b`.`title`           AS `title`,
       `b`.`author`          AS `author`,
       `br`.`borrow_date`    AS `borrow_date`,
       `br`.`due_date`       AS `due_date`,
       `br`.`return_date`    AS `return_date`,
       `br`.`status`         AS `status`,
       `br`.`renew_count`    AS `renew_count`,
       `fr`.`amount`         AS `fine_amount`,
       `fr`.`payment_status` AS `payment_status`
from (((`library_system`.`students` `s` join `library_system`.`borrow_records` `br`
        on ((`s`.`student_id` = `br`.`student_id`))) join `library_system`.`books` `b`
       on ((`br`.`isbn` = `b`.`isbn`))) left join `library_system`.`fine_records` `fr`
      on ((`br`.`student_id` = `fr`.`student_id`)))
order by `s`.`student_id`, `br`.`borrow_date` desc;

