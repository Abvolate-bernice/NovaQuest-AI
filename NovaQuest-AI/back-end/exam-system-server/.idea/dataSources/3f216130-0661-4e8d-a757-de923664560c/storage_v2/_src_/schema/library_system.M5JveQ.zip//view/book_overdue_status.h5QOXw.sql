create definer = root@localhost view book_overdue_status as
select `b`.`isbn`                                      AS `isbn`,
       `b`.`title`                                     AS `title`,
       `b`.`author`                                    AS `author`,
       `s`.`student_id`                                AS `student_id`,
       `s`.`name`                                      AS `student_name`,
       `s`.`department`                                AS `department`,
       `br`.`borrow_date`                              AS `borrow_date`,
       `br`.`due_date`                                 AS `due_date`,
       `br`.`return_date`                              AS `return_date`,
       (to_days(curdate()) - to_days(`br`.`due_date`)) AS `days_overdue`,
       `fr`.`amount`                                   AS `fine_amount`,
       `fr`.`payment_status`                           AS `payment_status`
from (((`library_system`.`books` `b` join `library_system`.`borrow_records` `br`
        on ((`b`.`isbn` = `br`.`isbn`))) join `library_system`.`students` `s`
       on ((`br`.`student_id` = `s`.`student_id`))) left join `library_system`.`fine_records` `fr`
      on ((`br`.`student_id` = `fr`.`student_id`)))
where ((`br`.`status` = '逾期') or ((`br`.`status` = '借出') and (`br`.`due_date` < curdate())));

