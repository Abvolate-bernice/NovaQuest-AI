create definer = root@localhost view reservation_queue as
select `r`.`reservation_id`                                                         AS `reservation_id`,
       `b`.`isbn`                                                                   AS `isbn`,
       `b`.`title`                                                                  AS `title`,
       `s`.`student_id`                                                             AS `student_id`,
       `s`.`name`                                                                   AS `student_name`,
       `r`.`reservation_date`                                                       AS `reservation_date`,
       `r`.`status`                                                                 AS `status`,
       row_number() OVER (PARTITION BY `b`.`isbn` ORDER BY `r`.`reservation_date` ) AS `queue_position`
from ((`library_system`.`reservations` `r` join `library_system`.`books` `b`
       on ((`r`.`isbn` = `b`.`isbn`))) join `library_system`.`students` `s` on ((`r`.`student_id` = `s`.`student_id`)))
where (`r`.`status` = '等待')
order by `b`.`isbn`, `r`.`reservation_date`;

