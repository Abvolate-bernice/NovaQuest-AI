create definer = root@localhost view orderitem_total as
select ((`cpso`.`orderitems`.`Quantity` * `cpso`.`orderitems`.`Discount`) *
        `cpso`.`products`.`Price`) AS `Quantity*Discount*Price`
from `cpso`.`products`
         join `cpso`.`orderitems`
where (`cpso`.`products`.`PID` = `cpso`.`orderitems`.`PID`);

