create definer = root@localhost view department_borrow_stats as
select `s`.`department`                                            AS `department`,
       count(distinct `s`.`student_id`)                            AS `total_students`,
       count(`br`.`borrow_id`)                                     AS `total_borrows`,
       count(distinct `br`.`isbn`)                                 AS `unique_books_borrowed`,
       avg(`br`.`renew_count`)                                     AS `avg_renew_count`,
       sum((case when (`br`.`status` = '逾期') then 1 else 0 end)) AS `overdue_count`,
       coalesce(sum(`fr`.`amount`), 0)                             AS `total_fines`
from ((`library_system`.`students` `s` left join `library_system`.`borrow_records` `br`
       on ((`s`.`student_id` = `br`.`student_id`))) left join `library_system`.`fine_records` `fr`
      on ((`s`.`student_id` = `fr`.`student_id`)))
group by `s`.`department`;

