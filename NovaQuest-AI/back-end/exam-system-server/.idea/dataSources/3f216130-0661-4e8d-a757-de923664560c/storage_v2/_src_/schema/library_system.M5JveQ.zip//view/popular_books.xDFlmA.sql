create definer = root@localhost view popular_books as
select `b`.`isbn`                        AS `isbn`,
       `b`.`title`                       AS `title`,
       `b`.`author`                      AS `author`,
       `b`.`publisher`                   AS `publisher`,
       `bc`.`category_name`              AS `category_name`,
       count(`br`.`borrow_id`)           AS `borrow_count`,
       avg(`br`.`renew_count`)           AS `avg_renew_count`,
       count(distinct `br`.`student_id`) AS `unique_borrowers`,
       `b`.`available_copies`            AS `available_copies`,
       `b`.`total_copies`                AS `total_copies`
from ((`library_system`.`books` `b` join `library_system`.`book_categories` `bc`
       on ((`b`.`category_code` = `bc`.`category_code`))) left join `library_system`.`borrow_records` `br`
      on ((`b`.`isbn` = `br`.`isbn`)))
where (`br`.`borrow_date` >= '2023-01-01')
group by `b`.`isbn`, `b`.`title`, `b`.`author`, `b`.`publisher`, `bc`.`category_name`, `b`.`available_copies`,
         `b`.`total_copies`
order by `borrow_count` desc
limit 20;

