create definer = root@localhost trigger calculate_fine_on_return
    after update
    on borrow_records
    for each row
BEGIN
    DECLARE days_overdue INT;
    DECLARE daily_fine DECIMAL(10,2) DEFAULT 1.00; -- 每天罚款金额

    -- 仅在状态从非“已还”变为“已还”时触发
    IF NEW.status = '已还' AND OLD.status != '已还' THEN
        SET days_overdue = DATEDIFF(NEW.return_date, NEW.due_date);

        IF days_overdue > 0 THEN
            INSERT INTO fine_records (
                student_id,
                amount,
                reason,
                payment_status,
                created_date
            ) VALUES (
                NEW.student_id,
                days_overdue * daily_fine,
                CONCAT('图书逾期归还，逾期天数：', days_overdue),
                '未缴纳',
                CURRENT_TIMESTAMP
            );
        END IF;
    END IF;
END;

