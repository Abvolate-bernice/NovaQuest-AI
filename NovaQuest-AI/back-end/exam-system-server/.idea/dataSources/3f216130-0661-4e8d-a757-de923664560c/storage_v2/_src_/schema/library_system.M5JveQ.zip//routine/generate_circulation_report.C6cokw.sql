create
    definer = root@localhost procedure generate_circulation_report(IN start_date date, IN end_date date)
BEGIN
    -- 创建临时表存储统计结果
    DROP TEMPORARY TABLE IF EXISTS temp_circulation_stats;
    CREATE TEMPORARY TABLE temp_circulation_stats (
        category_code VARCHAR(20),
        category_name VARCHAR(100),
        total_borrows INT,
        total_returns INT,
        total_overdue INT,
        total_fines DECIMAL(10,2)
    );

    -- 统计各分类的借阅情况
    INSERT INTO temp_circulation_stats
    SELECT
        bc.category_code,
        bc.category_name,
        COUNT(br.borrow_id) as total_borrows,
        SUM(CASE WHEN br.status = '已还' THEN 1 ELSE 0 END) as total_returns,
        SUM(CASE WHEN br.status = '逾期' THEN 1 ELSE 0 END) as total_overdue,
        COALESCE(SUM(fr.amount), 0) as total_fines
    FROM books b
    JOIN book_categories bc ON b.category_code = bc.category_code
    LEFT JOIN borrow_records br ON b.isbn = br.isbn
    LEFT JOIN fine_records fr ON br.student_id = fr.student_id AND br.borrow_id = (SELECT borrow_id FROM borrow_records WHERE isbn = br.isbn AND student_id = br.student_id AND return_date = fr.created_date ORDER BY created_at DESC LIMIT 1) -- 尝试关联到准确的罚款记录
    WHERE br.borrow_date BETWEEN start_date AND end_date
    GROUP BY bc.category_code, bc.category_name
    ORDER BY total_borrows DESC;

    -- 返回统计结果
    SELECT * FROM temp_circulation_stats;

    -- 清理临时表
    DROP TEMPORARY TABLE IF EXISTS temp_circulation_stats;
END;

