create
    definer = root@localhost procedure send_overdue_notifications()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_student_id VARCHAR(20);
    DECLARE v_email VARCHAR(100);
    DECLARE v_book_title VARCHAR(255);
    DECLARE v_days_overdue INT;

    -- 声明游标，查找所有“借出”状态且已逾期的记录
    DECLARE cur CURSOR FOR
        SELECT
            br.student_id,
            s.email,
            b.title,
            DATEDIFF(CURRENT_DATE, br.due_date) as days_overdue
        FROM borrow_records br
        JOIN students s ON br.student_id = s.student_id
        JOIN books b ON br.isbn = b.isbn
        WHERE br.status = '借出'
        AND br.due_date < CURRENT_DATE
        -- 避免重复发送：检查 notification_logs 中是否有近期（如1天内）已发送的相同类型通知
        AND NOT EXISTS (
            SELECT 1 FROM notification_logs nl
            WHERE nl.student_id = br.student_id
            AND nl.notification_type = '逾期提醒'
            AND nl.notification_content LIKE CONCAT('%', b.title, '%')
            AND nl.created_at >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY)
        );

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    -- 打开游标
    OPEN cur;

    -- 处理每条逾期记录
    read_loop: LOOP
        FETCH cur INTO v_student_id, v_email, v_book_title, v_days_overdue;
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- 插入通知日志
        INSERT INTO notification_logs (
            student_id,
            notification_type,
            notification_content,
            created_at
        ) VALUES (
            v_student_id,
            '逾期提醒',
            CONCAT('您借阅的图书《', v_book_title, '》已逾期', v_days_overdue, '天，请尽快归还。'),
            CURRENT_TIMESTAMP
        );
        -- 实际应用中，这里会调用外部服务发送邮件或短信
    END LOOP;

    -- 关闭游标
    CLOSE cur;
END;

