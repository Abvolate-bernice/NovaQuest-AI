create definer = root@localhost trigger after_borrow_update_return
    after update
    on borrow_records
    for each row
BEGIN
    -- 仅在状态从非“已还”变为“已还”时触发
    IF NEW.status = '已还' AND OLD.status != '已还' THEN
        UPDATE books
        SET available_copies = available_copies + 1,
            updated_at = CURRENT_TIMESTAMP
        WHERE isbn = NEW.isbn;

        UPDATE students
        SET current_borrow_count = current_borrow_count - 1,
            updated_at = CURRENT_TIMESTAMP
        WHERE student_id = NEW.student_id;
    END IF;
END;

