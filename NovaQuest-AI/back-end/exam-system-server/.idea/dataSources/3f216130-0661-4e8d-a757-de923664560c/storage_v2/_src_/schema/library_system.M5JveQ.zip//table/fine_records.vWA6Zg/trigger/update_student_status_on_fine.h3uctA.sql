create definer = root@localhost trigger update_student_status_on_fine
    after insert
    on fine_records
    for each row
BEGIN
    DECLARE total_unpaid_fine DECIMAL(10,2);
    DECLARE fine_threshold DECIMAL(10,2) DEFAULT 50.00; -- 罚款阈值

    -- 计算该学生未缴纳的罚款总额
    SELECT COALESCE(SUM(amount), 0)
    INTO total_unpaid_fine
    FROM fine_records
    WHERE student_id = NEW.student_id
    AND payment_status != '已缴纳';

    -- 如果未缴纳罚款总额达到阈值，则冻结账户
    IF total_unpaid_fine >= fine_threshold THEN
        UPDATE students
        SET account_status = '冻结',
            updated_at = CURRENT_TIMESTAMP
        WHERE student_id = NEW.student_id;
    END IF;
END;

