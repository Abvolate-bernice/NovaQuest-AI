create definer = root@localhost view orderitem_number as
select sum(`cpso`.`orderitems`.`Quantity`) AS `sum(Quantity)`
from `cpso`.`orderitems`
group by `cpso`.`orderitems`.`OID`;

