create definer = root@localhost view digital_products as
select `cpso`.`products`.`PID`       AS `PID`,
       `cpso`.`products`.`PName`     AS `PName`,
       `cpso`.`products`.`Price`     AS `Price`,
       `cpso`.`products`.`Cattegory` AS `Cattegory`,
       `cpso`.`products`.`SID`       AS `SID`
from `cpso`.`products`
where (`cpso`.`products`.`Cattegory` = '数码产品');

