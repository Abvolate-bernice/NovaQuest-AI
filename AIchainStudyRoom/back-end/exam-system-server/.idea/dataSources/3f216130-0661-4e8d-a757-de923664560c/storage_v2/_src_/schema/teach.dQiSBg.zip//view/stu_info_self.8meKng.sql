create definer = root@localhost view stu_info_self as
select `teach`.`student`.`SNO`    AS `SNO`,
       `teach`.`student`.`SName`  AS `SName`,
       `teach`.`student`.`Ssex`   AS `Ssex`,
       `teach`.`student`.`Sbirth` AS `Sbirth`,
       `teach`.`student`.`Sphone` AS `Sphone`,
       `teach`.`student`.`Saddr`  AS `Saddr`,
       `teach`.`student`.`ClsNO`  AS `ClsNO`,
       `teach`.`student`.`Danme`  AS `Danme`
from `teach`.`student`
where (`teach`.`student`.`SName` = '李勇');

grant select on table stu_info_self to 李勇;

