create definer = root@localhost view stu_info_score as
select min(`teach`.`sc`.`Score`) AS `min(score)`,
       max(`teach`.`sc`.`Score`) AS `max(score)`,
       avg(`teach`.`sc`.`Score`) AS `avg(score)`
from `teach`.`student`
         join `teach`.`sc`
where (`teach`.`student`.`SNO` = `teach`.`sc`.`SNO`);

grant select on table stu_info_score to 王明;

